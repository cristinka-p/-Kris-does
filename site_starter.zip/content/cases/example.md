---
title: "Пример кейса"
preview: "/assets/images/example.png"
---
## Описание
Здесь будет описание кейса.
